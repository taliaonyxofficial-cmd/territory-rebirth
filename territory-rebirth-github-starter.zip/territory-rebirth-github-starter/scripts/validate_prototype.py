from pathlib import Path
import re
import sys

path = Path("index.html")
if not path.exists():
    sys.exit("ERROR: index.html not found")
html = path.read_text(encoding="utf-8")
checks = {
    "HTML doctype": "<!DOCTYPE HTML" in html.upper(),
    "title": bool(re.search(r"<title>.*?</title>", html, re.I | re.S)),
    "main city label": "Химер-Сити" in html,
    "combat function": bool(re.search(r"function\s+processTurn\s*\(", html)),
    "combat setup": bool(re.search(r"function\s+startCombat\s*\(", html)),
    "inventory function": bool(re.search(r"function\s+renderInventory\s*\(", html)),
    "script tag": "<script" in html.lower() and "</script>" in html.lower(),
}
failed = [name for name, passed in checks.items() if not passed]
for name, passed in checks.items():
    print(f"{'PASS' if passed else 'FAIL'}: {name}")
if failed:
    sys.exit("Basic validation failed: " + ", ".join(failed))
print("Basic validation passed. This does not replace browser gameplay testing.")
